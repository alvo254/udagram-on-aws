"use strict";
const cost = 2;
console.log(cost);
const james = {
    name: 'adrian',
    age: 22
};
console.log(james.name + ' ' + james.age);
//# sourceMappingURL=learn.js.map